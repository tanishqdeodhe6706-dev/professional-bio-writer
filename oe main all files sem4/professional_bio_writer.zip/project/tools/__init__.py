"""
tools/
======
Package containing:
  - search.py  : Tavily web-research integration
  - catalog.py : Prompt templates + AI bio generation
"""
