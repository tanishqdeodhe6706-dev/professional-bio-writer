"""
Professional Bio Writer
========================
Main entry point for the CLI-based bio generation application.
Handles argument parsing, user input, orchestration, and output saving.
"""

import os
import sys
import argparse
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from config import Config
from tools.search import TavilySearchTool
from tools.catalog import BioGenerator

# ─────────────────────────────────────────────
# CLI Argument Parser
# ─────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    """Define and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="bio-writer",
        description="✍️  Professional Bio Writer – Generate short, medium, and long bios powered by AI.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python app.py
  python app.py --name "Jane Doe" --role "Product Manager" --industry "Tech" --experience "10 years leading cross-functional teams" --format linkedin
  python app.py --name "John Smith" --role "Speaker" --industry "Finance" --format speaker
        """,
    )

    # Optional direct input flags (if not provided, app prompts interactively)
    parser.add_argument("--name",       type=str, help="Full name of the person")
    parser.add_argument("--role",       type=str, help="Professional role/title")
    parser.add_argument("--industry",   type=str, help="Industry or domain")
    parser.add_argument("--experience", type=str, help="Summary of experience")
    parser.add_argument(
        "--format",
        type=str,
        choices=["website", "linkedin", "speaker"],
        default="website",
        help="Tone/platform for the bio (default: website)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="outputs",
        help="Directory to save generated bios (default: outputs/)",
    )
    parser.add_argument(
        "--no-search",
        action="store_true",
        help="Skip Tavily web research even if API key is available",
    )

    return parser


# ─────────────────────────────────────────────
# Interactive Input Collection
# ─────────────────────────────────────────────

def collect_user_input(args: argparse.Namespace) -> dict:
    """
    Collect user input either from CLI flags or interactively via prompts.
    Returns a dict with keys: name, role, industry, experience, format.
    """
    print("\n" + "=" * 55)
    print("  ✍️   PROFESSIONAL BIO WRITER")
    print("=" * 55)

    def prompt(flag_value: str, label: str, required: bool = True) -> str:
        """Return flag value if set, otherwise prompt the user."""
        if flag_value:
            print(f"  {label}: {flag_value}")
            return flag_value.strip()
        while True:
            value = input(f"  Enter {label}: ").strip()
            if value or not required:
                return value
            print(f"  ⚠️  {label} is required. Please try again.")

    print("\n📝 Enter the following details:\n")
    name       = prompt(args.name,       "Full Name")
    role       = prompt(args.role,       "Professional Role/Title")
    industry   = prompt(args.industry,   "Industry / Domain")
    experience = prompt(args.experience, "Experience Summary (1–3 sentences)")

    # Format selection (interactive if not passed as flag)
    if args.format and args.format in ("website", "linkedin", "speaker"):
        fmt = args.format
        print(f"  Bio Format:  {fmt}")
    else:
        print("\n  Select Bio Format:")
        print("    [1] website   – Professional website / About page")
        print("    [2] linkedin  – LinkedIn profile summary")
        print("    [3] speaker   – Speaker profile / conference bio")
        choice = input("  Choice (1/2/3) [default: 1]: ").strip() or "1"
        fmt_map = {"1": "website", "2": "linkedin", "3": "speaker"}
        fmt = fmt_map.get(choice, "website")

    print()
    return {
        "name": name,
        "role": role,
        "industry": industry,
        "experience": experience,
        "format": fmt,
    }


# ─────────────────────────────────────────────
# Output Saving
# ─────────────────────────────────────────────

def save_output(output_dir: str, name: str, bios: dict, fmt: str) -> str:
    """
    Save generated bios to a text file in the output directory.
    Returns the path of the saved file.
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Sanitize name for filename
    safe_name = name.lower().replace(" ", "_").replace("/", "-")
    filename = f"{safe_name}_bio.txt"
    filepath = Path(output_dir) / filename

    divider = "=" * 60

    lines = [
        divider,
        f"  PROFESSIONAL BIO – {name.upper()}",
        f"  Format: {fmt.capitalize()}",
        divider,
        "",
        "── SHORT BIO (≈50 words) " + "─" * 34,
        "",
        bios.get("short", ""),
        "",
        "── MEDIUM BIO (≈150 words) " + "─" * 32,
        "",
        bios.get("medium", ""),
        "",
        "── LONG BIO (≈300 words) " + "─" * 34,
        "",
        bios.get("long", ""),
        "",
        divider,
        "Generated by Professional Bio Writer",
        divider,
    ]

    with open(filepath, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    return str(filepath)


# ─────────────────────────────────────────────
# Display Bios in Terminal
# ─────────────────────────────────────────────

def display_bios(bios: dict, user_data: dict) -> None:
    """Pretty-print all three bios to the terminal."""
    name = user_data["name"]
    fmt  = user_data["format"]

    print("\n" + "=" * 60)
    print(f"  📄 GENERATED BIOS FOR: {name.upper()}")
    print(f"  🎯 Format: {fmt.capitalize()}")
    print("=" * 60)

    sections = [
        ("SHORT BIO  (~50 words)",  "short"),
        ("MEDIUM BIO (~150 words)", "medium"),
        ("LONG BIO   (~300 words)", "long"),
    ]

    for label, key in sections:
        print(f"\n── {label} {'─' * (55 - len(label))}")
        print()
        print(bios.get(key, "⚠️  Bio not generated."))
        print()


# ─────────────────────────────────────────────
# Main Orchestration
# ─────────────────────────────────────────────

def main():
    parser  = build_parser()
    args    = parser.parse_args()

    # 1. Validate config / API keys
    config = Config()
    if not config.is_ai_configured():
        print("\n❌ ERROR: No AI API key found.")
        print("   Please set OPENAI_API_KEY or GEMINI_API_KEY in your .env file.")
        print("   See .env.example for reference.\n")
        sys.exit(1)

    # 2. Collect user data
    user_data = collect_user_input(args)

    # 3. Optional Tavily research
    tone_context = ""
    if config.tavily_api_key and not args.no_search:
        print("🔍 Fetching tone/style references via Tavily...")
        searcher = TavilySearchTool(api_key=config.tavily_api_key)
        tone_context = searcher.research_tone(
            industry=user_data["industry"],
            platform=user_data["format"],
        )
        if tone_context:
            print("✅ Tone research complete.\n")
        else:
            print("⚠️  Tavily returned no results – proceeding without web context.\n")
    elif not config.tavily_api_key:
        print("ℹ️  No TAVILY_API_KEY found – skipping web research.\n")

    # 4. Generate bios
    print("🤖 Generating bios with AI...\n")
    generator = BioGenerator(config=config)

    try:
        bios = generator.generate_all(
            name=user_data["name"],
            role=user_data["role"],
            industry=user_data["industry"],
            experience=user_data["experience"],
            platform=user_data["format"],
            tone_context=tone_context,
        )
    except Exception as e:
        print(f"\n❌ Bio generation failed: {e}")
        sys.exit(1)

    # 5. Display bios
    display_bios(bios, user_data)

    # 6. Save to file
    saved_path = save_output(
        output_dir=args.output_dir,
        name=user_data["name"],
        bios=bios,
        fmt=user_data["format"],
    )
    print(f"💾 Bios saved to: {saved_path}\n")


if __name__ == "__main__":
    main()
